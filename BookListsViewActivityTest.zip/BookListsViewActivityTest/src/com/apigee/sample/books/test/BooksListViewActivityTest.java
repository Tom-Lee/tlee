package com.apigee.sample.books.test;

import android.test.ActivityInstrumentationTestCase2;
import android.app.Activity;
import junit.framework.AssertionFailedError;
import com.bitbar.recorder.extensions.ExtSolo;
import android.widget.Button;
import android.widget.EditText;
import java.util.Random;

/**
 * BooksListViewActivityTest --- test cases to test SDK sample app 'books'
 * @author    tlee
 * Version:   v1
 */

public class BooksListViewActivityTest extends ActivityInstrumentationTestCase2<Activity> {

	private static final String LAUNCHER_ACTIVITY_CLASSNAME = "com.apigee.sample.books.BooksListViewActivity";
	private static Class<?> launchActivityClass;
	static {
		try {
			launchActivityClass = Class.forName(LAUNCHER_ACTIVITY_CLASSNAME);
		} catch (ClassNotFoundException e) {
			throw new RuntimeException(e);
		}
	}
	private ExtSolo solo; 

	@SuppressWarnings("unchecked")
	public BooksListViewActivityTest() {
		super((Class<Activity>) launchActivityClass);
	}

	@Override
	public void setUp() throws Exception {
		super.setUp();
		solo = new ExtSolo(getInstrumentation(), getActivity(), this.getClass()
				.getCanonicalName(), getName());
		checkApplicationAvailable(solo);
	}

	@Override
	public void tearDown() throws Exception {
		solo.finishOpenedActivities();
		solo.tearDown();
		super.tearDown();
	}

	/**
	 * Main test method
	 * @throws Exception
	 */
	public void testBooksApp() throws Exception {
			// perform the test
			
			//TODO: Test book list
			testBookList(solo);
			
			// Test Add book
			testAddNewBook(solo);
			testAddExistBook(solo);
		
	}
	
	/**
	 * Goal: Check if view list exists
	 * @throws Exception
	 */
	private void checkApplicationAvailable(ExtSolo solo) throws Exception {
		
	}
	
	/**
	 * Goal:
	 * 1) Get book items and check if the total number of items on UI matches remote server
	 * 2) Go through each item and check if the book title match remote server
	 * @throws Exception
	 */
	private void testBookList(ExtSolo solo) throws Exception {
		
	}
	
	/**
	 * Goal:
	 * Test Add Book feature to perform adding a book and check if 
	 * the book is added.
	 * 
	 * @throws Exception
	 */
	private void testAddNewBook(ExtSolo solo) throws Exception {
		
		Random generator = new Random();
		int  n = generator.nextInt(9998) + 1;
		
		String title = "Test title " + n;
		String author ="Test author";
		
		try {
			
			//Click the Add book button 
			solo.clickOnMenuItem("Add Book", true);
			if (solo.waitForActivity("NewBookActivity", 2000)){

					if (solo.waitForEditTextById("com.apigee.sample.books.R.id.title", 2000) && solo.waitForEditTextById("com.apigee.sample.books.R.id.author", 2000) ){
						
						//Type in title and author
						solo.enterText((EditText) solo.findViewById("com.apigee.sample.books.R.id.title"),title);
						solo.enterText((EditText) solo.findViewById("com.apigee.sample.books.R.id.author"), author);
						
					}else{
						Exception e = new Exception("title id and author id is not available");
	                    throw e;
					}
			}else{
				Exception e = new Exception("'NewBookActivity' is not avilable");
                throw e;
			}
			if(solo.waitForButtonById("com.apigee.sample.books.R.id.create", 2000)){
				//Tap create button
				solo.clickOnButton((Button) solo.findViewById("com.apigee.sample.books.R.id.create"));
				solo.waitForActivity("BooksListViewActivity");
				solo.sleep(2000);
			}else{
				Exception e = new Exception("the create button is not available");
                throw e;
			}
			//assertTrue("Wait for list (index: 0) failed."solo.waitForList(0, 2000));
		}catch (AssertionFailedError e) {
			solo.fail("com.apigee.sample.books.test.BooksListViewActivityTest.testAddNewBook_scr_fail",e);
			throw e;
		} catch (Exception e) {
			solo.fail("com.apigee.sample.books.test.BooksListViewActivityTest.testAddNewBook_scr_fail",e);
			throw e;
		}
	}

	/**
	 * Add a exist book
	 * @throws Exception
	 */
	private void testAddExistBook(ExtSolo solo) throws Exception {
		
	}

	
}
