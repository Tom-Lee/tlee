/** Automatically generated file. DO NOT MODIFY */
package com.apigee.sample.books.test;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}